
<?php 
session_start();
if (!isset($_SESSION['user_logged'])){
	header('Location:index.php?loginfirst=yes');
}
require_once('../connection.php');
include('navigation.php');


if(isset($_GET['file']))
{
	?>
	<script type="text/javascript">

		alert("Invalid File Format selected..!!!");
	</script>
	<?php
}
if(isset($_GET['update']))
{
	?>
	<script type="text/javascript">

		alert('Slider Image Upadated ..!!');
	</script>
	<?php
}
?>

	<div class="container">
		<legend> Slider Image </legend>
		<a class="btn btn-primary" href="dashboard.php">Back</a>

		<?php 

		$query_check = "SELECT * FROM tbl_sliderImage AS s, tbl_level AS l WHERE s.level_image=l.level_id";
		$result = $conn->query( $query_check );
		?>
		<table class="table table-bordered" >
			<tr class="heading">
				<th>S/N</th>
				<th>Level</th>
				<th>Image</th>
				<th>Action</th>
			</tr>

			<?php
			while($data = $result->fetch_array())
			{
				?>
				<tr>
					<td><?php echo  $data['image_id']; ?></td>
					<td><?php echo $data['level_name']; ?></td>
					<td><img src='sliderImage/<?php echo $data['image_name']; ?>' width="150px" height="150px" alt="Image Unavailable"/></td>

					<td >
						<a  class="btn btn-success" href="updateSliderImage.php?id=<?php echo $data['image_id']; ?>" >UPDATE</a>

					</td>

				</tr>
				<?php
			}
			?>
		</table>

	</div>
</body>
</html>