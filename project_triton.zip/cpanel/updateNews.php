<?php 
session_start();
if (!isset($_SESSION['user_logged'])){
	header('Location:index.php?loginfirst=yes');
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Update News</title>
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/bootstrap.css"/>
</head>
<?php 

if(isset($_GET['file']))
{
	?>
	<script type="text/javascript">

		alert("Invalid File Format selected..!!!");
	</script>
	<?php
}
require_once('../connection.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$query_check = "SELECT * FROM tbl_news WHERE news_id='$id'";
	$result = $conn->query( $query_check );
	while($data = $result->fetch_array())
	{
		?>
		<body>
			<div class="container">
				<form lpformnum="1" class="form-control" method="POST" enctype = "multipart/form-data">
					<fieldset>
						<legend>Update News</legend>

						<div class="form-group">
							<input type="hidden" name="id" value="<?php echo $data['news_id']?>"/>
							<input type="hidden" name="oldFile" value="<?php echo $data['featured_image']?>"/>

							<label for="exampleInputEmail1">News Headline</label>
							<input type="text" required="required" name="heading" class="form-control" id="" aria-describedby="" value="<?php echo $data['news_heading']; ?>" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABHklEQVQ4EaVTO26DQBD1ohQWaS2lg9JybZ+AK7hNwx2oIoVf4UPQ0Lj1FdKktevIpel8AKNUkDcWMxpgSaIEaTVv3sx7uztiTdu2s/98DywOw3Dued4Who/M2aIx5lZV1aEsy0+qiwHELyi+Ytl0PQ69SxAxkWIA4RMRTdNsKE59juMcuZd6xIAFeZ6fGCdJ8kY4y7KAuTRNGd7jyEBXsdOPE3a0QGPsniOnnYMO67LgSQN9T41F2QGrQRRFCwyzoIF2qyBuKKbcOgPXdVeY9rMWgNsjf9ccYesJhk3f5dYT1HX9gR0LLQR30TnjkUEcx2uIuS4RnI+aj6sJR0AM8AaumPaM/rRehyWhXqbFAA9kh3/8/NvHxAYGAsZ/il8IalkCLBfNVAAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;">

						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">News Content</label>
							<textarea type="text" required="required" name="news_content" class="form-control" id="" aria-describedby=""  style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABHklEQVQ4EaVTO26DQBD1ohQWaS2lg9JybZ+AK7hNwx2oIoVf4UPQ0Lj1FdKktevIpel8AKNUkDcWMxpgSaIEaTVv3sx7uztiTdu2s/98DywOw3Dued4Who/M2aIx5lZV1aEsy0+qiwHELyi+Ytl0PQ69SxAxkWIA4RMRTdNsKE59juMcuZd6xIAFeZ6fGCdJ8kY4y7KAuTRNGd7jyEBXsdOPE3a0QGPsniOnnYMO67LgSQN9T41F2QGrQRRFCwyzoIF2qyBuKKbcOgPXdVeY9rMWgNsjf9ccYesJhk3f5dYT1HX9gR0LLQR30TnjkUEcx2uIuS4RnI+aj6sJR0AM8AaumPaM/rRehyWhXqbFAA9kh3/8/NvHxAYGAsZ/il8IalkCLBfNVAAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%;"><?php echo $data['news_content']; ?></textarea>

						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">News From(Level)</label>
							<select class="form-control" name="level">
								<option disabled >Select..</option>
								<?php
								$query_check = "SELECT * FROM tbl_level";
								$result = $conn->query( $query_check );
								while($row = $result->fetch_array())
								{
									?>
									<option value="<?php echo $row['level_id']?>" <?php if( $data['news_level']==$row['level_id']) echo 'selected="selected"';?>><?php echo $row['level_name']?></option>
									<?php
								}
								?>
							</select>

						</div>

						<div class="form-group">
							<label for="exampleInputFile">File Attached</label>
							<input type="file" name="file" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
							<small id="fileHelp" class="form-text text-muted">If there is Image file attached with News, Upload from here.</small>
						</div>

					</fieldset>
					<button type="submit" name="update" class="btn btn-primary">Update</button>
				</fieldset>
			</form>
		</div>
	</body>
	<?php
}
}
?>
</html>
<?php 

if(isset($_POST['update'])){
	
	$headline = $_POST['heading'];	
	$level = $_POST['level'];	
	$news_content = $_POST['news_content'];	
	$id=$_POST['id'];
	
	if($_FILES['file']['name'] == TRUE){
		$oldFile=$_POST['oldFile'];

		$fname = $_FILES['file']['name'];
		$ext = pathinfo($fname, PATHINFO_EXTENSION);
		$date= date('Y=m-d H:i:s');

		$new_name = md5(uniqid($date,true))."_Trinton.".$ext;

		if($ext=='gif'|| $ext =='png' || $ext=='jpg'){

			move_uploaded_file($_FILES['file']['tmp_name'],'newsImage/'.$new_name);

			unlink("newsImage/".$oldFile);

			$insert= "UPDATE tbl_news SET news_heading='$headline', news_content='$news_content', news_level='$level', featured_image='$new_name' WHERE news_id='$id'";

			$conn->query($insert);

			header("location:news.php?update=success");
		}else{
			header("location:updateNews.php?file=fail");
		}
	}else{
		$insert= "UPDATE tbl_news SET news_heading='$headline', news_content='$news_content', news_level='$level' WHERE news_id='$id'";

		$conn->query($insert);

		header("location:news.php?update=success");
	}

}
?>