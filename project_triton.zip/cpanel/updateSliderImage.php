<?php 
session_start();
if (!isset($_SESSION['user_logged'])){
	header('Location:index.php?loginfirst=yes');
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Image(Slider)</title>
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/bootstrap.css"/>
</head>
<?php 

if(isset($_GET['file']))
{
	?>
	<script type="text/javascript">

		alert("Invalid File Format selected..!!!");
	</script>
	<?php
}
require_once('../connection.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$query_check = "SELECT * FROM tbl_sliderImage WHERE image_id='$id'";
	$result = $conn->query( $query_check );
	while($data = $result->fetch_array())
	{
		?>
		<body>
			<div class="container">
				<form lpformnum="1" class="form-control" method="POST" enctype = "multipart/form-data">
					<fieldset>
						<legend>Publish Notice</legend>
						<input type="hidden" name="id" value="<?php echo $data['image_id']?>"/>
						<input type="hidden" name="oldFile" value="<?php echo $data['image_name']?>"/>
						
						<div class="form-group">
							<label for="exampleInputFile">Image</label>
							<input type="file" name="file" required="required" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
							<small id="fileHelp" class="form-text text-muted">If you want to update slidder Image, Upload from here.</small>
						</div>

					</fieldset>
					<button type="submit" name="update" class="btn btn-primary">Update</button>
				</fieldset>
			</form>
		</div>
	</body>
	<?php
}
}
?>
</html>
<?php 

if(isset($_POST['update'])){

	$id=$_POST['id'];
	
	$oldFile=$_POST['oldFile'];

	$fname = $_FILES['file']['name'];
	$ext = pathinfo($fname, PATHINFO_EXTENSION);
	$date= date('Y=m-d H:i:s');

	$new_name = md5(uniqid($date,true))."_Triton.".$ext;

	if($ext=='gif'|| $ext =='png' || $ext=='jpg'){

		move_uploaded_file($_FILES['file']['tmp_name'],'sliderImage/'.$new_name);

		unlink("sliderImage/".$oldFile);

		$update= "UPDATE tbl_sliderimage SET  image_name='$new_name' WHERE image_id='$id'";

		$conn->query($update);

		header("location:sliderImage.php?update=success");
	}else{
		header("location:updateSliderImage.php?file=fail");
	}

}
?>