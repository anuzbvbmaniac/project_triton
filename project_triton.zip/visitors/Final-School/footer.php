	<div class="footer">
					<div class="container">
						<div class="row">
							<div class="social"> <a href="https://www.facebook.com/triton.edu.np/" class="link facebook" target="_parent"><span class="fa fa-facebook-square"></span></a> <a href="https://twitter.com/PageOnlineXS" class="link twitter" target="_parent"><span class="fa fa-twitter"></span></a> <a href="https://plus.google.com/+OndřejBárta-Otaku" class="link youtube" target="_parent"><span class="fa fa-youtube-square"></span></a> </div>
						</div>
					</div>
					<div class="container">
						<div class="row">
							<div class="col-sm-4"> <img src="img/phone.png">
								<div class="footer-text">
									<h4>Tel: 01-5104529, 5104450</h4>
									<h4>Toll Free No.: 1660-01-04450</h4>
								</div>
							</div>
							<div class="col-sm-4"> <img src="img/email.png">
								<div class="footer-text">
									<h4>Email</h4>
									<h4>tritonintlcollege@gmail.com</h4>
								</div>
							</div>
							<div class="col-sm-4"> <img src="img/location.png">
								<div class="footer-text">
									<h4>Location</h4>
									<h4>Tinkune, Kathmandu, Nepal</h4>
								</div>
							</div>
						</div>
					</div>
				</div>
			</body>
			</html>